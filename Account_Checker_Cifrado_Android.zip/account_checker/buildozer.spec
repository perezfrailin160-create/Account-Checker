[app]
title = Account Checker
package.name = accountchecker
package.domain = org.accountchecker
source.dir = .
source.include_exts = py,kv,png,jpg,txt
version = 1.0.0
requirements = python3,kivy,androidstorage4kivy,pyaes
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 35
android.minapi = 24
android.archs = arm64-v8a

[buildozer]
log_level = 2
warn_on_root = 1
